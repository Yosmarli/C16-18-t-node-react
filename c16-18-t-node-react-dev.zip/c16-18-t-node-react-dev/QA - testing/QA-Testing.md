 Link de casos de prueba - Blas
```
https://onedrive.live.com/edit?id=D1A2F563235F9D21!s4e75f3a71fc64e708974d6a939dbac90&resid=D1A2F563235F9D21!s4e75f3a71fc64e708974d6a939dbac90&cid=d1a2f563235f9d21&ithint=file%2Cxlsx&redeem=aHR0cHM6Ly8xZHJ2Lm1zL3gvYy9kMWEyZjU2MzIzNWY5ZDIxL0VhZnpkVTdHSDNCT2lYVFdxVG5ickpBQkMyOTA1WFhQeG1hTUpETExvU1dkTmc_ZT1yampkamo&migratedtospo=true&wdo=2
```

 Link de casos de prueba - Yosmarli
```
https://onedrive.live.com/view.aspx?resid=990F4578673B0239%21187&authkey=!AN-tHFUJjdp6Ssg
```

 Link de casos de prueba - reReTesteo
```
https://onedrive.live.com/view.aspx?resid=990F4578673B0239%21193&authkey=!AJKipFpFixEs-vE
```