export const businessCollection = "business";
export const ordersCollection = "orders";
export const usersCollection = "users";
export const productsCollection = "products";
export const productTypeCollection = "productType";