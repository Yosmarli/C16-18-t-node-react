import Swal from "sweetalert2";
import { useCart } from "../../stores/useCart";
import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../auth/context/AuthContext";

const Summary = () => {
  const { subtotal, clearCart, clearSubtotal } = useCart();
  const { user } = useContext(AuthContext);
  const [shippingCost, setShippingCost] = useState(700);
  const navigate = useNavigate();
  const total = subtotal.reduce(
    (accumulator, product) => accumulator + parseInt(product.productSubtotal),
    0
  );

  const handlePurchase = () => {
    if (user) {
      Swal.fire({
        text: "Tu pedido fue realizado",
        icon: "success",
        customClass: {
          container: "w-auto",
        },
      }).then(() => {
        clearCart();
        clearSubtotal();
        setShippingCost(0);
        navigate("/purchase-success");
      });
    } else {
      Swal.fire({
        text: "Debes iniciar sesion para realizar una compra",
        icon: "error",
        customClass: {
          container: "w-auto",
        },
      });
    }
  };

  return (
    <div className="w-5/6 lg:w-11/12 xl:w-[424px] sm:h-[296px] border rounded-lg mx-8 mt-8 sm:ml-16 lg:mt-12 lg:ml-16 p-6 border-platinum flex flex-col">
      <h4 className="text-base sm:text-xl font-normal leading-7">
        Resumen de compra:
      </h4>
      <div className="text-sm font-normal leading-5 flex justify-between py-3">
        <p className="font-poppins">Subtotal:</p>
        <p>${total}</p>
      </div>
      <hr className="text-platinum" />
      <div className="text-sm font-normal leading-5 flex justify-between py-3">
        <p className="font-poppins">Envio:</p>
        <p>${shippingCost}</p>
      </div>
      <hr className="text-platinum" />
      <div className="flex justify-between py-3">
        <p className="font-bold text-lg leading-7">Total:</p>
        <p className="font-bold text-lg leading-5">${total + shippingCost}</p>
      </div>
      <button
        onClick={handlePurchase}
        className="mt-4 py-4 px-10 bg-avocadoGreen sm:w-96 rounded-full text-white font-semibold text-base self-center"
      >
        Realizar compra
      </button>

      {/* {isExploding && <ConfettiExplosion />} */}
    </div>
  );
};

export default Summary;
