

const products = [
  {
    id: 1,
    image: "/product-harinademaiz.svg",
    category: "Sin TACC",
    name: "Harina de maíz",
    rating: 4.5,
    price: 1000.00
  },
  {
    id: 2,
    image: "/product-granola-vegana.svg",
    category: "Vegano",
    name: "Granola vegana 1kg",
    rating: 4.5,
    price: 950.00
  },
  {
    id: 3,
    image: "/product-hamburguesas.svg",
    category: "Keto",
    name: "Hamburguesas Amaranto y arroz yamaní",
    rating: 4.5,
    price: 950.00
  },
  {
    id: 4,
    image: "/product-chocolate.svg",
    category: "Keto",
    name: "Chocolate sin azúcar",
    rating: 4.5,
    price: 350.00
  },
  {
    id: 5,
    image: "/product-tortillavegana.svg",
    category: "Vegano",
    name: "Tortilla vegana",
    rating: 4.5,
    price: 1000.00
  },
  {
    id: 6,
    image: "/product-dulcedelechevegano.svg",
    category: "Vegano",
    name: "Dulce de leche vegano",
    rating: 4.5,
    price: 2000.00
  },
  {
    id: 7,
    image: "/product-heladodefrutilla.svg",
    category: "Sin TACC",
    name: "Helado de frutilla",
    rating: 4.5,
    price: 2000.00
  },
  {
    id: 8,
    image: "/product-lechedealmendras.svg",
    category: "Keto",
    name: "Leche de almendras",
    rating: 4.5,
    price: 2000.00
  },
  {
    id: 9,
    image: "/product-chocolate.svg",
    category: "Sin azúcar",
    name: "Chocolate sin azúcar",
    rating: 4.5,
    price: 12.99
  },
  {
    id: 10,
    image: "/product-chocolate.svg",
    category: "Sin azúcar",
    name: "Chocolate sin azúcar",
    rating: 4.5,
    price: 12.99
  },
];


export default products;
