const categories = [
    {
        image:"/noname0.svg",
        name: 'SIN T.A.C.C'
    },
    {
        image:"/noname1.svg",
        name: 'SIN EXCESO DE AZUCAR'
    },
    {
        image:"/noname.svg",
        name: 'KETO'
    },
    {
        image:"/noname4.svg",
        name: 'VEGANO'
    },
    {
        image:"/noname3.svg",
        name: 'ORGÁNICO'
    },
    {
        image:"/noname2.svg",
        name: 'DIABÉTICO'
    }

]

export default categories